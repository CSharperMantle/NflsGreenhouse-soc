<?php
/*
GET Params:
  air_temp 空气温度
  air_hum 空气湿度
  air_light 空气亮度
  ground_hum 地面湿度
*/


?>