<?php
    require 'assets\\php\\shared.php';

    set_session_logged_off();
    redirect_to('index.html');
?>