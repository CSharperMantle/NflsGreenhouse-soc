/*Concurrent Tasks*/

module.exports = {
  options:{
    logConcurrentOutput: true
  },
  dev:{
    tasks: ['server','watch']
  }
};