/*Dist remove folders*/

module.exports = {
	install:{
    options:{
      force: true
    },
    src: ['src/assets/lib']
  },
  dist:{
    src: ['dist']
  }
};