/*!
 * Maisonnette - Documentation v0.0.1 (http://foxythemes.net/themes/maisonnette)
 * Copyright 2014-2018 Foxy Themes all rights reserved 
 */

var App={init:function(t){prettyPrint()}};